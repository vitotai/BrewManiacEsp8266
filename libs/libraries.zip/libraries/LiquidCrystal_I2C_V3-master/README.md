LiquidCrystal_I2C_V3
====================

A Arduino Library for use Text-LCDs (HD44780) on I2C over PCF8574-I2C-Portextender-IC with different pin assignment
